package com.automation.utils;

import com.automation.pages.BasePage;
import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.RequestOptions;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ApiHelper extends BasePage {

    private static final Logger log = LoggerFactory.getLogger(ApiHelper.class);

    public String getBearerToken(){
        String tenantId = "67080e55-9c90-409b-9421-7fab7df8331b";
        String tokenUrl = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

        Map<String, String> formParams = new HashMap<>();
        formParams.put("client_id", getEnvConfig("AUTH_CLIENT_ID"));
        formParams.put("client_secret", getEnvConfig("AUTH_CLIENT_SECRET_VALUE"));
        formParams.put("scope", getEnvConfig("AUTH_TENANT_ID")+"/.default");
        formParams.put("grant_type", "client_credentials");

        Response response = RestAssured
                .given().urlEncodingEnabled(true)
                .contentType("application/x-www-form-urlencoded")
                .formParams(formParams)
                .post(tokenUrl).then().statusCode(200).extract().response();

        log.info("Access Token:" + response.path("access_token"));
        return response.path("access_token").toString();
    }

    private APIRequestContext getAPIContext() {
        APIRequestContext apiRequestContext;
        Playwright playwright = Playwright.create();
        apiRequestContext = playwright.request().newContext(new APIRequest.NewContextOptions()
                .setBaseURL(getEnvConfig("baseURL").trim())
                .setIgnoreHTTPSErrors(true)
                .setExtraHTTPHeaders(Map.of(
                        "Authorization", "Bearer " + dataStorage.parseString("$Bearer_Token_FE").trim(),
                        "Content-Type", "application/json"
                )));
        return apiRequestContext;
    }

    public void disposeAPIContext() {
        getAPIContext().dispose();
        log.info("API Context Disposed...!");
    }

    public APIResponse getAPIResponse_PostCall(String endpoint, String requestBody) {
        Instant requestStartTime = Instant.now();
        APIResponse resposne= getAPIContext().post(endpoint, RequestOptions.create().setData(requestBody));
        Instant requestEndTime= Instant.now();
        long responseTime = Duration.between(requestStartTime,requestEndTime).toSeconds();
        log.info("Response Time: "+responseTime);
        dataStorage.put("ResponseTime",responseTime);
        return resposne;
    }

    public boolean validateResponseContainsText(String actualResponse, String expectedResponse) {
        log.info("****ACTUAL RESPONSE****");
        log.info(actualResponse);
        if (actualResponse.contains(expectedResponse)) {
            return true;
        } else
            return false;
    }

    public boolean validateResponseTime(long expectedTime){
        log.info("Expected Response Time: "+expectedTime +" sec");
        log.info("Actual Response Time: "+dataStorage.parseString("$ResponseTime")+" sec");
        long actualResponseTime= Long.parseLong(dataStorage.parseString("$ResponseTime"));
        if(actualResponseTime<=expectedTime)
            return true;
        else
            return false;
    }

}
