package com.automation.pages.HR_InterviewGuide;

import com.automation.pages.BasePage;
import com.automation.pages.pageStructure;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InterviewGuideLoginPage extends BasePage implements pageStructure {
	
	private Logger log= LoggerFactory.getLogger(InterviewGuideDashboardPage.class);
	private Page page;

	//webelement locators
	private String loginPageHeader= "//h2[text()='Interview Guide Designer']";
	private String termsAndConditionCheckbox= "//p[contains(text(),'Agree to the')]/preceding-sibling::span/input";
	private String signIn_Btn= "//button[text()='Sign In']";

	//page methods
	public InterviewGuideLoginPage(Page page) {
		this.page = page;
	}

	public boolean launchHomepage() {
		page.navigate(getEnvConfig("application_url_interview_guide").trim());
		if(isLoaded()) {
			basepage.captureScreenshot();
			return true;
		}
		else
			return false;
	}

	public boolean verifySignInDisabled(){
		if(waitForElementToBeVisible(page,signIn_Btn)){
			return page.locator(signIn_Btn).isDisabled();
		}
		else
			return false;
	}

	public boolean login(){
		waitAndClick(page,termsAndConditionCheckbox);
		basepage.captureScreenshot();
		waitAndClick(page,signIn_Btn);
		return interviewGuideDashboardPage.isLoaded();
	}

	@Override
	public boolean isLoaded() {
		//write logic to check if page is loaded
		page.waitForLoadState(LoadState.DOMCONTENTLOADED); // Wait for the DOM to be loaded
//		page.waitForLoadState(LoadState.NETWORKIDLE);
		return waitForElementToBeVisible(page,loginPageHeader);
	}
}
