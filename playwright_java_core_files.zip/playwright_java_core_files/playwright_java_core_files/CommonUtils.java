package com.automation.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.automation.common.Mappings;
import com.automation.constants.Constant;
import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonUtils extends Mappings {

	private static final Logger log = LoggerFactory.getLogger(CommonUtils.class);

	public Boolean setProperties(String fileName, String key, String value) {
		
		Boolean status=false;
		
		try {
			FileInputStream fis = new FileInputStream(Constant.CONFIG_FILE_PROPERTIES_DIRECTORY+fileName+".properties");
			Properties prop = new Properties();
			prop.load(fis);
			fis.close();
			FileOutputStream out = new FileOutputStream(Constant.CONFIG_FILE_PROPERTIES_DIRECTORY+fileName+".properties");
			prop.setProperty(key, value);
			prop.store(out, null);
			out.close();
			status =true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return status;
	}
	
	public Properties getProperties(String fileName) {
		Properties prop = new Properties();
		try {
			FileInputStream in = new FileInputStream(Constant.CONFIG_FILE_PROPERTIES_DIRECTORY+fileName+".properties");
			prop.load(in);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return prop;
	}

	public boolean waitForElementToBeVisible(Page page, String locator){
		Locator myElement = page.locator(locator);
		try {
			log.info("Waiting for the element:  ["+locator+"]");
			myElement.waitFor(new Locator.WaitForOptions().setTimeout(Constant.TIMEOUT_MILLISEC));
			return myElement.isVisible();
			// Element is visible
		} catch (Exception e) {
			// Element is not visible within the timeout
			e.printStackTrace();
			return false;
		}
	}

	public boolean waitForElementToBeNotVisible(Page page, String locator, int maxWaitTime_seconds){
		int seconds=1;
		Locator myElement = page.locator(locator);
		try {
			while(myElement.isVisible() && maxWaitTime_seconds>=seconds){
				log.info("Element still visible. Waiting to disappear");
				waitforsec(1);
				seconds++;
			}
			//element is not visible
			log.info("Element disappeared...!");
			return true;
		} catch (Exception e) {
			// Element is not visible within the timeout
			e.printStackTrace();
			return false;
		}
	}

	public boolean waitForElementToBeVisible(Page page, Locator locator){
		try {
			log.info("Waiting for the element: ["+locator+"]");
			locator.waitFor(new Locator.WaitForOptions().setTimeout(Constant.TIMEOUT_MILLISEC));
			return locator.isVisible();
			// Element is visible
		} catch (Exception e) {
			// Element is not visible within the timeout
			e.printStackTrace();
			return false;
		}
	}

	public boolean waitForNthElementToBeVisible(Page page, String locator, int index){
		Locator myElement = page.locator(locator).nth(index);
		try {
			log.info("Waiting for the element:  ["+locator+"]");
			myElement.waitFor(new Locator.WaitForOptions().setTimeout(Constant.TIMEOUT_MILLISEC));
			return myElement.isVisible();
			// Element is visible
		} catch (Exception e) {
			// Element is not visible within the timeout
			e.printStackTrace();
			return false;
		}
	}

	public boolean waitForLastMatchElementToBeVisible(Page page, String locator){
		Locator myElement = page.locator(locator).last();
		try {
			log.info("Waiting for the element:  ["+locator+"]");
			myElement.waitFor(new Locator.WaitForOptions().setTimeout(Constant.TIMEOUT_MILLISEC));
			scrollToElement(page,locator);
			return myElement.isVisible();
			// Element is visible
		} catch (Exception e) {
			// Element is not visible within the timeout
//			e.printStackTrace();
			return false;
		}
	}

	public void waitAndClick(Page page, String locator){
		if(waitForElementToBeVisible(page,locator)){
			try {
				log.info("Trying to click the element: ["+locator+"]");
				page.locator(locator).click();
			} catch (Exception e) {
				log.error("Click action failed...!");
				e.printStackTrace();
				customAssert.assertFalse(true);
			}
		}
		else{
			log.error("Element not visible..! Cannot perform click..!");
			customAssert.assertFalse(true);
		}

	}

	public void waitAndClickNthElement(Page page, String locator, int index){
		if(waitForNthElementToBeVisible(page,locator,index)){
			try {
				log.info("Trying to click the element: ["+locator+"]");
				page.locator(locator).nth(index).click();
			} catch (Exception e) {
				log.error("Click action failed...!");
				e.printStackTrace();
			}
		}
		else{
			log.error("Element not visible..! Cannot perform click..!");
		}

	}

	public void waitAndClickLastElement(Page page, String locator){
		if(waitForLastMatchElementToBeVisible(page,locator)){
			try {
				log.info("Trying to click the element: ["+locator+"]");
				page.locator(locator).last().click();
			} catch (Exception e) {
				log.error("Click action failed...!");
				e.printStackTrace();
			}
		}
		else{
			log.error("Element not visible..! Cannot perform click..!");
		}

	}

	public String waitAndGetText(Page page, String locator) {
		if (waitForElementToBeVisible(page, locator)) {
			try {
				log.info("Trying to fetch text from the element: [" + locator + "]");
				log.info("Fetched text is: ["+page.locator(locator).textContent().trim()+"]");
				return page.locator(locator).textContent().trim();
			} catch (Exception e) {
				log.error("Failed to fetch text...!");
				e.printStackTrace();
				return null;
			}
		} else {
			log.error("Element not visible..!");
			return null;
		}

	}

	public Page switchToNewTab(String locator,Page parentPage){
		Page newPage= parentPage.waitForPopup(()->{
			waitAndClick(parentPage,locator);
		});
		return newPage;
	}

	public ArrayList<String> waitAndGetListOfText(Page page, String locator) {
		ArrayList<String> trendingQuesList = new ArrayList<>();

		Locator myElement= page.locator(locator).nth(0);
		if(waitForElementToBeVisible(page,myElement)) {
			List<ElementHandle> elements = page.querySelectorAll("xpath=" + locator);
			log.info("Size of List:" + elements.size());
			for (ElementHandle element : elements) {
				log.info("Text fetched: ["+element.innerText().trim()+"]");
				trendingQuesList.add(element.innerText().trim());
			}
		}
		return trendingQuesList;
	}

	public void enterText(Page page, String locator,String value){
		try {
			if (waitForElementToBeVisible(page, locator)) {
				page.locator(locator).fill(value);
				log.info("Entered Text: [" + value + "]");
				waitforsec(2);
			}
			else
				log.error("Element not visible...!");
		}
		catch (Exception e){
			e.printStackTrace();
		}

	}

	public void clearText(Page page, String locator){
		try {
			if (waitForElementToBeVisible(page, locator)) {
				page.locator(locator).clear();
				log.info("Cleared the text value");
				waitforsec(2);
			}
			else
				log.error("Element not visible...!");
		}
		catch (Exception e){
			e.printStackTrace();
		}

	}

	public boolean waitForElementToDisappear(Page page, String locator){
		Locator myElement = page.locator(locator);
		try {
			log.info("Waiting for the element: ["+locator+"]");
			myElement.waitFor(new Locator.WaitForOptions().setTimeout(Constant.TIMEOUT_MILLISEC));
			while(myElement.isVisible()) {
				waitforsec(3);
			}
			log.info("Element disappeared...!");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public String createDynamicLocator(String locator,String textToReplace, String replacementValue){
		return locator.replace(textToReplace,replacementValue);
	}

	public boolean scrollToElement(Page page,String locator){
		try {
			if (waitForElementToBeVisible(page, locator)) {
				page.locator(locator).scrollIntoViewIfNeeded();
				waitforsec(2);
				return true;
			}
			else
				log.error("Element not visible...!");
				return false;
		}
		catch (Exception e){
			e.printStackTrace();
			return false;
		}
	}

	public void hoverOverElement(Page page, String locator){
		try {
			if (waitForElementToBeVisible(page, locator)) {
				scrollToElement(page,locator);
				page.locator(locator).hover();
				waitforsec(2);
			}
			else
				log.error("Element not visible...!");
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

	public void hoverOverNthElement(Page page, String locator, int index){
		try {
			if (waitForNthElementToBeVisible(page, locator,index)) {
				page.locator(locator).nth(index).hover();
				waitforsec(2);
			}
			else
				log.error("Element not visible...!");
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

	public void verifyCharLength(Page page, String locator, int length) {
		try {
			if(page.locator(locator).count() == length) {
				log.info("SUCCESS: Verified the max char count..");
			}
			else
				log.error("Max char limit failing for feedback comment textbox...!");
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}

	public String generateRandomString(int length) {
		String generatedString = RandomStringUtils.randomAlphabetic(250);

		return generatedString;
	}

	public void closeBrowser(){
		getPage().close();
	}

	public String getTodaysDate(){
		LocalDate today = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String formattedDate = today.format(formatter);
		return formattedDate;
	}

	public void uploadFile(Page page, String locator, String filePath){
		waitForElementToBeVisible(page,locator);
		page.setInputFiles(locator, Paths.get(filePath));
	}
	
}